"use strict";(()=>{chrome.runtime.onInstalled.addListener(()=>{console.log("SaveIt extension installed.")});})();
